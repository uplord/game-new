extends Control

@export_range(0.0, 1.0) var progress := 0.75:
	set(value):
		progress = clamp(value, 0.0, 1.0)
		queue_redraw()

@export var border_size := 1.0
@export var thickness := 4.0
@export var background_thickness := 4.0

@export var background_color := Color("ffffff66") # Dark red
@export var progress_color := Color.RED

func _draw() -> void:
	var center := size * 0.5
	var radius := (size.x - border_size * 2 - thickness) * 0.5
	print("radius", radius)
	draw_arc(
		center,
		radius,
		0.0,
		TAU,
		64,
		background_color,
		background_thickness,
		true
	)

	draw_arc(
		center,
		radius,
		deg_to_rad(-90),
		deg_to_rad(-90 + progress * 360.0),
		64,
		progress_color,
		thickness,
		true
	)
